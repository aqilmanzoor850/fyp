import React, { Component } from 'react'
import { View, Text } from 'react-native';


class UpdateProblem extends Component {
    state = {  }
    render() { 
        return ( <View>
            <Text>asdasdas</Text>
        </View> );
    }
}
 
export default UpdateProblem;